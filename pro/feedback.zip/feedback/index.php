	
<?php
 
    $hostname="localhost";
    $username="root";
    $password="123";
    $database="feedback";
    $teachers_table="teachers";
    $infrastructure_table="infrastructure";

    $conn= mysqli_connect($hostname,$username,$password,$database);

    if(mysqli_connect_errno())
		echo "failed to connect to database";





    $teacherlist=[];
    //Creating teachers list from database
    $result=mysqli_query($conn,"SELECT * FROM ".$teachers_table);
 	while( $row=mysqli_fetch_array($result,MYSQLI_NUM) )
        {
		  if($row[0]!="")
		      for($i=1; $i<count($row); $i+=13)
				  if(($row[$i]!="") && (!in_array($row[$i], $teacherlist))  )
				    $teacherlist[count($teacherlist)]=$row[$i];
        }
    mysqli_free_result($result);

         

   



    //generate blank multidimensional associated arrays for storing required data of each teacher
    for($i=0; $i<count($teacherlist); $i++)
    	    {
    	     $teachers[$teacherlist[$i] ]=[           // question_no  => [point1=>0 , point2=>0 ],
																	1 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	2 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	3 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	4 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	5 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	6 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	7 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	8 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	9 => [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	10=> [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	11=> [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
																	12=> [1=>0, 2=>0, 3=>0, 4=>0, 5=>0  ] ,
		    	    		               ];              
    	    }

    //Reading feedback data of each teacher into array $teacher [teacher_name][question][point]
	$result=mysqli_query($conn,"SELECT * FROM ".$teachers_table);
	while( $row=mysqli_fetch_array($result,MYSQLI_NUM) )
		{

			//if first field of record is not empty then 'if' condition is true 
			if($row[0]!="")
				 //a 'for' loop through each teacher in the record read. note:there are 12 questions for each teacher therefore $i+=13
				 for($i=1; $i<count($row) ; $i+=13)
				 	  //if the teacher name is not empty then 'if' condition is true
				 	  if( $row[$i]!="" )
				 	  	    //a 'for' loop through each question of that $i position teacher
				 	  	  	for( $j= $i+1; $j< ($i+13)  ; $j+=1)//this loop runs 12 times
				 	  	        if($row[$j]!=0)
				 	  	      //$data["teachername"][questionno] [pointno] ++(increase count of that point of that question of that teacher)
				 	  	   	    $teachers[$row[$i]]     [ ($j-1)%13] [$row[$j]]++; 	  	  
		}
    mysqli_free_result($result);









    //create blank multidimensional array for storing required data for infrastructure
    $infrastructure;
        for($q=0;$q<17;$q++)      
        	for($p=0;$p<5;$p++)
        		$infrastructure[$q][$p]=0;
        	 
    //Reading feedback data of infrastructure into array $infrastructure [question][point]
 	$result=mysqli_query($conn,"SELECT * FROM ".$infrastructure_table);
    while( $row=mysqli_fetch_array($result,MYSQLI_NUM) )
    {
		//if first entry at line is not empty then 'if' condition is true 
		if($row[0]!="")

			//a 'for' loop through each question in the line read through csv file.
			for( $j= 1; $j<18   ; $j++)//this loop runs 17 times
			   if($row[$j]!=0)
			   	  //$infrastructure[question_no-1][point_no-1     ]++;
			        $infrastructure [$j-1]        [ $row[$j]-1 ] ++;	  	  
    }
    mysqli_free_result($result);
 


mysqli_close($conn);


    mkdir("images");
    if(!is_dir("pdf"))
      mkdir("pdf");

?>



<html>
	<head>
		  <title>Feedback pdf generator</title>
		  <script src="requires/bargraph.js"></script> 
	</head>
	<body>
          <p id="status"></p>
	      <canvas id="graph" width="900" height="600"></canvas>
          <form name="form1" method="POST" accept-charset="utf-8">
          	  <input name="image data" id="image_data" type="hidden" />
          	  <input name="filename data" id="filename_data" type="hidden" />
          </form>
          <form name="form2" method="POST" accept-charset="utf-8">
          	 <input name="teacher name" id="teacher_name" type="hidden"/> 
          </form>
          
	</body>
</html>







  <script>
	    function saveAsPDF(formname,variableId,pdfname,phpfilename)
	    {
	    	document.getElementById(variableId).value=pdfname;
		    var fd = new FormData(document.forms[formname]);
		    var xhr = new XMLHttpRequest();
		    xhr.open('POST', phpfilename, true);
			xhr.send(fd);
	    }







//fetching data from php for html canvas-------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------

 var no_of_teachers=<?php echo count($teacherlist) ?> ;
 
 var teacherlistasstring='<?php       
                                   $number_of_teachers=count($teacherlist);
                                   for($i=0 ; $i<$number_of_teachers ;$i++ )
                                   	{ 
                                   		echo $teacherlist[$i]; 
                                   		if($i!=($number_of_teachers-1))
                                   		echo ",";
                                   	} 
                          ?>' ;

 var teacherlist=teacherlistasstring.split(",") ;


 var teachers=[<?php 
	               for($t=0; $t<$number_of_teachers ; $t++ )
	               	{

               	      	echo "[";
                        for($q=1; $q<=12 ;$q++)
                        {

                      	 	echo "[";
          	 	            for($p=1; $p<=5 ;$p++)
          	 	            {

      	 	            		$value=$teachers[$teacherlist[$t]][$q][$p];
      	 	            		echo $value; 
      	 	            		if($p!=5)
      	 	            			echo ",";
          	 	            }
                            echo "]";
   	      	                if($q!=12)
   	      		                echo ",";
                        }
               	      	echo "]";
               	      	if($t!=($number_of_teachers-1))
               	      		echo ",";
	               	}
               ?>];


 var infrastructure=[<?php
				   	        for($q=0;$q<17;$q++)
					        { 

					        	echo "[";
					        	for($p=0;$p<5;$p++)
					        	{

					        		 echo $infrastructure[$q][$p];
					        		 if($p!=4)
					        		 	echo",";
					        	}
					          echo "]";
					          if($q!=16)
					          	echo ",";
					        }
                    ?>];

//---------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------





    //drawing graph for each question
    for(var teacher=0; teacher<no_of_teachers; teacher++)
    {
        var no_of_students=0;
        var xvals=["Strongly Disagree" , "Disagree" , "Satisfactory" , "Agree" , "Strongly Agree" ];
        for(var question=0;question<12;question++)
        { 
        	var oncomplete=false;
        	var yvals=[];

        	for(var point=0; point<5 ;point++)
        		yvals[point]=teachers[teacher][question][point];

            var sum=0;
  	        for(var i=0;i<yvals.length;i++)
                sum+=yvals[i];
            no_of_students=sum;

            //loop for rounding off digits after two decimal points
            for(var i=0;i<yvals.length;i++)
  	        {
              yvals[i]=yvals[i]*10000/sum ;
              yvals[i]=parseInt(yvals[i]);
              yvals[i]/=100;
  	        }

          
  	      oncomplete=drawBarGraph("graph",xvals,yvals,"Question "+(question+1),"Points given","Percentage of students",40,50,90);
  	      if(oncomplete) saveGraph("graph",teacherlist[teacher]+"_Question_"+(question+1),"form1","image_data","filename_data");
        }
    }



    //drawing graph for all questions
    for(var teacher=0; teacher<no_of_teachers; teacher++)
    {  
    	var oncomplete=false;
        var no_of_students=teachers[teacher][0][0]+teachers[teacher][0][1]+teachers[teacher][0][2]+teachers[teacher][0][3]+teachers[teacher][0][4];
        var xvals=[];
        var yvals=[];
        for(var question=0;question<12;question++)
        {  
            xvals[question]="Q"+(question+1);
            yvals[question]=0;              	
        	for(var point=0; point<5 ;point++)
        		yvals[question]+=teachers[teacher][question][point]*(point+1);

        }

        //loop for rounding off digits after two decimal points
        for(var i=0;i<yvals.length;i++)
	        {
	        	yvals[i]=yvals[i]*20/no_of_students*100;
            yvals[i]=parseInt(yvals[i]);
            yvals[i]/=100;
	        }

          
  	      oncomplete=drawBarGraph("graph",xvals,yvals,teacherlist[teacher],"Question number","Average feedback points",25,30,35);
  	      if(oncomplete) saveGraph("graph",teacherlist[teacher],"form1","image_data","filename_data");
    }





    var sum=0;
    for(var point=0; point<5 ;point++)
        sum+=infrastructure[0][point];

    //drawing graph for each question of infrastructure              
        var xvals=["Below Average" , "Average" , "Good" , "Very Good" , "Excellent" ];
        for(var question=0;question<17;question++)
        { var oncomplete=false;
        	var yvals=[];

        	for(var point=0; point<5 ;point++)
        		yvals[point]=infrastructure[question][point];

            //loop for rounding off digits after two decimal points
            for(var i=0;i<yvals.length;i++)
  	        {
	              yvals[i]=yvals[i]*10000/sum ;
	              yvals[i]=parseInt(yvals[i]);
	              yvals[i]/=100;
  	        }

          
  	      oncomplete=drawBarGraph("graph",xvals,yvals,"Question "+(question+1),"Points given","Percentage of students",40,50,90);
  	      if(oncomplete) saveGraph("graph","infrastructure_Question_"+(question+1),"form1","image_data","filename_data");
        }



    //drawing graph for all questions for infrastructure

    	var oncomplete=false;
        var xvals=[];
        var yvals=[];
        for(var question=0;question<17;question++)
        {  
            xvals[question]="Q"+(question+1);
            yvals[question]=0;              	
        	for(var point=0; point<5 ;point++)
        		yvals[question]+=infrastructure[question][point]*(point+1);
        }

        //loop for rounding off digits after two decimal points
        for(var i=0;i<yvals.length;i++)
	        {
		        yvals[i]=yvals[i]*20/sum*100;
	            yvals[i]=parseInt(yvals[i]);
	            yvals[i]/=100;
	        }

          
	      oncomplete=drawBarGraph("graph",xvals,yvals,"Infrastructure","Question number","Average feedback points",13,23,27);
	      if(oncomplete) saveGraph("graph","infrastructure","form1","image_data","filename_data");

   clearCanvas("graph","white");


    //creating pdf for each teacher
    for(var t=0;t<no_of_teachers;t++)   
    	saveAsPDF("form2","teacher_name",teacherlist[t],'requires/generate_pdf.php');

    //creating pdf for infrastructure
    saveAsPDF("form2","teacher_name","infrastructure","requires/infrastructure_pdf.php");

   </script>




