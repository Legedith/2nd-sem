

function drawBarGraph(canvasId,xvals,yvals,title,xlabel,ylabel,offset,barwidth,baroffset)
{
	var canvas=document.getElementById(canvasId);
    var ctx= canvas.getContext("2d");

  

   //background colour
   ctx.fillStyle="white";
   ctx.fillRect(0,0,900,600);

   //title
   ctx.fillStyle="#000000";
   ctx.textAlign="center";
   ctx.font = "25px Comic Sans MS";
   ctx.fillText(title, (xvals.length*(baroffset+barwidth)+offset)/2 ,33);

   //xlabel 
   ctx.fillStyle="#000000";
   ctx.font = "16px Consolas";
   ctx.fillText(xlabel,400,590);

   //ylabel
   
   ctx.rotate(-Math.PI/2);
   ctx.translate(-600,0);
   ctx.fillStyle="#000000";
   ctx.font = "16px Consolas";
   ctx.fillText(ylabel,250,15);
   ctx.translate(600,0);
   ctx.rotate(Math.PI/2);

   //graph draw area background colour
   ctx.fillStyle="white";
   ctx.fillRect(50,40,840,510);



   var draw_width=840;
   var draw_height=510;
   var draw_top_left_x=50;
   var draw_top_left_y=40;

   

   //push top left corner draw area to origin
   ctx.translate(draw_top_left_x , draw_top_left_y);

   for(var i=0;i<xvals.length;i++)
   {  
   	  //bar colour
      ctx.fillStyle="#22aaff";

   	  //draw bar
      ctx.fillRect(i*(baroffset+barwidth)+offset ,  draw_height*(100-yvals[i])/100 , barwidth , draw_height*yvals[i]/100);	

      //text colour
      ctx.fillStyle="#000000";
      ctx.textAlign="center";
      ctx.font = "14px Consolas";

      //bar height text
      ctx.fillText( yvals[i]+"%" , i*(baroffset+barwidth)+offset+ barwidth/2 , draw_height*(100-yvals[i])/100 -3 ) ;

      //bar name text
      ctx.fillText( xvals[i] , i*(baroffset+barwidth)+offset+ barwidth/2 , draw_height+16 ) ;

   }
   ctx.translate(-draw_top_left_x , -draw_top_left_y);

    //drawing x-axis and y-axis lines
    ctx.beginPath();
    ctx.moveTo(890,550);
    ctx.lineTo(50,550);
    ctx.lineTo(50,40);
    /*
		   //for rectangle
		    ctx.lineTo(890,40);
		    ctx.closePath();
    */
    ctx.stroke();


    //markings on y-axis line
    ctx.translate(draw_top_left_x-13 , draw_top_left_y);
    for(var i=0; i<=100 ; i+=10)
    {
    	ctx.fillStyle="#000000";
        ctx.textAlign="center";
        ctx.font = "12px Consolas";
    	ctx.fillText( i , 0 ,draw_height*(100-i)/100 );

        ctx.beginPath();
    	ctx.moveTo( 8 ,draw_height*(100-i)/100 );
    	ctx.lineTo( 12 ,draw_height*(100-i)/100 );
    	ctx.stroke();

    }
    ctx.translate(-draw_top_left_x+13 , -draw_top_left_y);


   return true;

}


function saveGraph(canvasId,filename,formname,image_data,filename_data)
{
	      		var imagedata= document.getElementById(canvasId).toDataURL("image/png");
	      		 document.getElementById(image_data).value = imagedata;
	      		 document.getElementById(filename_data).value = filename;
	      		 var fd = new FormData(document.forms[formname]);
	      		 var xhr = new XMLHttpRequest();
                xhr.open('POST', 'requires/save_image.php', true);
                xhr.send(fd);
	  


}


function clearCanvas(canvasId,colour)
{
	var canvas=document.getElementById(canvasId);
    var ctx= canvas.getContext("2d");
    ctx.fillStyle=colour;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

}