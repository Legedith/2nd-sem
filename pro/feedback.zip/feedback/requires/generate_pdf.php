<?php

  $teacher = $_POST['teacher_name'];

require 'fpdf/fpdf.php';

	$pdf = new FPDF('P','mm','A4');
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',16);
	$pdf->Text(105-strlen($teacher)*2,10,$teacher);


    $pdf->SetFont('Times',"I",9);
    $pdf->Text(10,21,'The students were asked twelve questions on the teacher\'s pedagogy in which they had to give a rating on a scale of 1-5.');
    $pdf->Text(10,26,'Description of ratings is as follows:-');
    $pdf->Text(10,30,'1 - Strongly Disagree');
    $pdf->Text(10,34,'2 - Disagree');
    $pdf->Text(10,38,'3 - Satisfactory Ratings given');
    $pdf->Text(10,42,'4 - Agree');
    $pdf->Text(10,46,'5 - Strongly Agree');

    $text="Question-wise analysis of ";
	$pdf->SetFont('Arial','BU',10);
	$pdf->Text(105-(strlen($text)+strlen($teacher)),66,$text.$teacher.":-");

    $pdf->SetFont('Times',"",10);
    $pdf->Text(10,90,'Q1. The teacher provides guidance/counseling in academic and non-academic matters in/outside the class.');
    $pdf->Image("../images/".$teacher."_Question_1.png",10,110,190);
    unlink("../images/".$teacher."_Question_1.png");


   $questions=
   [2=>"Q2. The teacher encourages participation and discussion in class. (Teacher-Student, Student-Student).",
    3=>"Q3. The teacher uses modern teaching aids/gadgets, handouts, suggestion of references, ppts, web resources, etc.",
    4=>"Q4. The teacher pays attention to academically weaker students as well.",
    5=>"Q5. The teacher is regular and punctual in class.",
    6=>"Q6. The teacher invites opinion and questions on subject matter from students.",
    7=>"Q7. The teacher inspires students for ethical conduct.",
    8=>"Q8. The teacher links the subject to real life experiences and creates interest in the subject.",
    9=>"Q9. The teacher covers the entire syllabus in time.",
    10=>"Q10. The teacher explains the topics efficiently.",
    11=>"Q11. Periodical assessments are conducted as per schedule.",
    12=>"Q12. The teacher uses non-traditional methods of evaluation like quiz,seminars,assignments,classroom presentations/participation (or "
   ];

   $pdf->SetFont('Times',"",10);
   for($i=2;$i<=12;$i++)
   {
   	$pdf->AddPage();
    $pdf->Text(10,26,$questions[$i]);
    if($i==12)
       $pdf->Text(20,30,"any other method).");
    $pdf->Image("../images/".$teacher."_Question_".$i.".png",10,56,190);
    unlink("../images/".$teacher."_Question_".$i.".png");

   }


    $pdf->AddPage();
    $text="Overall analysis of ";
	$pdf->SetFont('Arial','BU',10);
	$pdf->Text(105-(strlen($text)+strlen($teacher)),26,$text.$teacher.":-");
	$pdf->Image("../images/".$teacher.".png",5,56,200);
    unlink("../images/".$teacher.".png");





	$pdf->Output("../pdf/".$teacher.".pdf",'F'); 


?>