<?php

require 'fpdf/fpdf.php';

	$pdf = new FPDF('P','mm','A4');
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',16);
	$pdf->Text(105-strlen("Infrastructure")*2,10,"Infrastructure");


    $pdf->SetFont('Times',"I",9);
    $pdf->Text(10,21,'The students were asked six questions on the Infrastructure\'s pedagogy in which they had to give a rating on a scale of 1-5.');
    $pdf->Text(10,26,'Description of ratings is as follows:-');
    $pdf->Text(10,30,'1 - Below Average');
    $pdf->Text(10,34,'2 - Average');
    $pdf->Text(10,38,'3 - Good');
    $pdf->Text(10,42,'4 - Very Good');
    $pdf->Text(10,46,'5 - Excellent');


    $text="Question-wise analysis of College's Infrastructure:-";
	$pdf->SetFont('Arial','BU',10);
	$pdf->Text(105-strlen($text),66,$text);

    $pdf->SetFont('Times',"",10);
    $pdf->Text(10,90,'Q1. Sports facility in college.');
    $pdf->Image("../images/infrastructure_Question_1.png",10,110,190);
    unlink("../images/infrastructure_Question_1.png");


   $questions=
   [2=>"Q2. Medical facility in college.",
    3=>"Q3. Internet facility in college.",
    4=>"Q4. Extra-curricular activities in college.",
    5=>"Q5. Canteen facility in college.",
    6=>"Q6. Security and proctorial services in college.",
    7=>"Q7. Toilets/washrooms are hygienic and properly maintained.",
    8=>"Q8. Availability of clean drinking water in college.",
    9=>"Q9. Grievances/problems are redressed/resolved well in time.",
    10=>"Q10. The functioning of Placement Cell is satisfactory.",
    11=>"Q11. The building/classrooms are accessible to differently-abled persons.",
    12=>"Q12. Classrooms are clean and well maintained.",
    13=>"Q13. Availability of prescribed books/reading materials.",
    14=>"Q14. Availability of reading room and common room in college building.",
    15=>"Q15. Library staff are cooperative and helpful.",
    16=>"Q16. Availability and accessibility of online educational resources in college.",
    17=>"Q17. Way of cataloging and arrangement of books in the Library is helpful."
   ];

   $pdf->SetFont('Times',"",10);
   for($i=2;$i<=17;$i++)
   {
   	$pdf->AddPage();
    $pdf->Text(10,26,$questions[$i]);
    $pdf->Image("../images/infrastructure_Question_".$i.".png",10,56,190);
    unlink("../images/infrastructure_Question_".$i.".png");

   }


    $pdf->AddPage();
    $text="Overall analysis of Infrastructure :-";
	$pdf->SetFont('Arial','BU',10);
	$pdf->Text(105-strlen($text),26,$text);
	$pdf->Image("../images/infrastructure.png",5,56,200);
  unlink("../images/infrastructure.png");


	$pdf->Output("../pdf/infrastructure.pdf",'F'); 
 
 rmdir("../images");

?>