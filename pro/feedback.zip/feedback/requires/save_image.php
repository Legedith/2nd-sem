<?php

$img = $_POST['image_data'];
$filename = $_POST['filename_data'];
$img = str_replace('data:image/png;base64,', '', $img);
$img = str_replace(' ', '+', $img);
$data = base64_decode($img);
$success = file_put_contents("../images/".$filename.".png", $data);

?>